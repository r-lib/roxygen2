#' A solution to the halting problem
#' @references test
#'   @bibliography REFERENCES.bib
#'   @cite frankfurt:2010
#'   @cite non-existent-key
NA
