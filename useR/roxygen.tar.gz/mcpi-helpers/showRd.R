

showRd <- function(Rd, dir = "mcpi1.roxygen/man/") {
  filename <- file.path(dir, sprintf("%s.html", Rd))
  htmlfile <- Rd2HTML(sprintf("%s%s.Rd", dir, Rd),
                      out = filename)
  browseURL(htmlfile)
}

