

mcpi <- function(n, verbose = FALSE, return.xy = TRUE) {

  unif <- Unif()
  hits <- 0
  xys <- matrix(NA, nrow = n, ncol = 3)
   
  for ( i in seq_len(n) ) {
    xy <- r(unif, 2)
    inside <- FALSE

    if ( xy[1]^2 + xy[2]^2 <= 1 ) {
      hits <- hits + 1
      inside <- TRUE
    }

    if ( verbose )
      cat(ifelse(inside, "+", "-"))

    xys[i, ] <- c(xy, inside)
  }
  
  pi <- 4 * hits / n


  ret <- list(pi = pi, n = n, hits = hits)

  if ( return.xy )
    ret$xy <- xys

      
  structure(ret, class = "mcpi")
}



### Common S3 class "mcpi" methods: ##################################

print.mcpi <- function(x, ...) {
  cat(sprintf("%s\n", x$pi))
}


summary.mcpi <- function(object, ...) {
  cat(sprintf("%s (estimated by %s hits from %s trials)\n",
              object$pi, object$hits, object$n))
}


plot.mcpi <- function(x, y, col.inside = 2, col.outside = 1, ...) {
  xy <- x$xy[, 1:2]
  inside <- as.logical(x$xy[, 3])

  xcircle <- seq(0, 1, by = 0.0001)
  ycircle <- sqrt(1 - xcircle^2)

  col <- ifelse(inside, col.inside, col.outside)

  plot(x$xy, type = "p", col = col, ...)
  lines(xcircle, ycircle, col = col.inside, lwd = 2)

  invisible(x)
}



### A new S3 generic and its "mcpi" implementation: ##################

piconv <- function(x, ...) {
  UseMethod("piconv")
}


piconv.mcpi <- function(x, xlab = "Steps",
                        ylab = "MCPI convergence", ...) {
  inside <- x$xy[, 3]
  
  seqn <- seq(along = inside)
  piconv <- 4 * cumsum(inside) / seqn 
  
  piconvplot(piconv, xlab = xlab, ylab = ylab, ...)

  invisible(piconv)
}


piconvplot <- function(x, xlab, ylab, ...) {
  plot(x, type = "l", xlab = xlab, ylab = ylab, ...)
  abline(h = pi, lty = 2)
}



### Abstract S4 "Distribution" class and generics: ###################

setClass("Distribution",
         representation = representation("VIRTUAL",
           name = "character"))


setGeneric("r",
function(object, n, ...) {
  standardGeneric("r")
})


setGeneric("d",
function(object, x, ...) {
  standardGeneric("d")
})


setGeneric("q",
function(object, p, ...) {
  standardGeneric("q")
})


setGeneric("p",
function(object, q, ...) {
  standardGeneric("p")
})



### S4 uniform distribution implementation: ##########################

setClass("Unif",
         contains = c("Distribution"),
         representation = representation(
           min = "numeric",
           max = "numeric"),
         prototype = prototype(
           name = "Uniform distribution",
           min = 0,
           max = 1))


Unif <- function(min = 0, max = 1) {
  new("Unif", min = min, max = max)
}


setMethod("r", signature = signature(object = "Unif", n = "numeric"),
function(object, n) {
  runif(n, object@min, object@max)
})


setMethod("d", signature = signature(object = "Unif", x = "numeric"),
function(object, x, log = FALSE) {
  dunif(x, object@min, object@max, log = log)
})


setMethod("q", signature = signature(object = "Unif", p = "numeric"),
function(object, p, lower.tail = TRUE, log.p = FALSE) {
  qunif(p, object@min, object@max, lower.tail = lower.tail, log.p = log.p)
})


setMethod("p", signature = signature(object = "Unif", q = "numeric"),
function(object, q, lower.tail = TRUE, log.p = FALSE) {
  punif(q, object@min, object@max, lower.tail = lower.tail, log.p = log.p)
})
